<?php
$str = "This is a string";
echo $str;

?>